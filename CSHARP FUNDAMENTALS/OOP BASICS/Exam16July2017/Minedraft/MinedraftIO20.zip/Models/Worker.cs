﻿public abstract class Worker
{
    public string Id { get; protected set; }
    public virtual double OreOutput { get; protected set; }
    public virtual double EnergyRequirement { get; protected set; }
    public virtual double EnergyOutput { get; protected set; }
}