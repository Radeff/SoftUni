﻿using System;

public abstract class Harvester
{
    protected Harvester(string id, double oreOutput, double energyRequirement)
    {
        Id = id;
        OreOutput = oreOutput;
        EnergyRequirement = energyRequirement;
    }

    public string Id { get; }

    public double OreOutput { get; }

    public double EnergyRequirement
    {
        get { return this.EnergyRequirement; }

        set
        {
            if (this.EnergyRequirement >= 20000 || this.EnergyRequirement <= 0)
            {
                throw new Exception($"{nameof(Harvester)} is not registered, because of it's {nameof(this.EnergyRequirement)}");
            }
            this.EnergyRequirement = value;
        }
    }
}