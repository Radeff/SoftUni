﻿using System;

namespace _05.CardCompareTo
{
    public class Card : IComparable<Card>
    {
        private CardSuit suit;
        private CardRank rank;

        public Card(CardRank rank, CardSuit suit)
        {
            this.Rank = rank;
            this.Suit = suit;
        }

        public CardSuit Suit { get; set; }

        public CardRank Rank { get; set; }

        private int GetCardPower()
        {
            return (int)this.Rank + (int) this.Suit;
        }

        public override string ToString()
        {
            return $"Card name: {this.Rank} of {this.Suit}; Card power: {this.GetCardPower()}";
        }


        public int CompareTo(Card other)
        {
            if (ReferenceEquals(this, other)) return 0;
            if (ReferenceEquals(null, other)) return 1;
            var suitComparison = suit.CompareTo(other.suit);
            if (suitComparison != 0) return suitComparison;
            var rankComparison = rank.CompareTo(other.rank);
            if (rankComparison != 0) return rankComparison;
            var suitComparison1 = Suit.CompareTo(other.Suit);
            if (suitComparison1 != 0) return suitComparison1;
            return Rank.CompareTo(other.Rank);
        }
    }
}