﻿namespace _11.InfernoInfinity.Gems
{
    public class Gem
    {
        private int strength;
        private int agility;
        private int vitality;
        private int bonus;

        public Gem()
        {
            
        }

        public Gem(string clarity)
        {
            
            if (clarity == "Chipped")
            {
                this.Bonus = 1;
            }
            else if (clarity == "Regular")
            {
                this.Bonus = 2;
            }
            else if (clarity == "Perfect")
            {
                this.Bonus = 5;
            }
            else if (clarity == "Flawless")
            {
                this.Bonus = 10;
            }
        }

        public int Strength { get => strength; protected set => strength = value; }

        public int Agility { get => agility; protected set => agility = value; }

        public int Vitality { get => vitality; protected set => vitality = value; }
        public int Bonus { get => bonus; protected set => bonus = value; }
    }
}