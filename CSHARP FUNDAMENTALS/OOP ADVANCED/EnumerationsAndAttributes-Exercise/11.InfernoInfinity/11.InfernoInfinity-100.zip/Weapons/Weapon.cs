﻿using _11.InfernoInfinity.Gems;

namespace _11.InfernoInfinity
{
    public class Weapon
    {
        private int minDamage;
        private int maxDamage;
        private string name;
        private string rarity;
        private Gem[] sockets;
        private int bonusDamage;

        public Weapon()
        {

        }
        public Weapon(string name, string rarity)
        {
            if (rarity == "Uncommon")
            {
                this.BonusDamage = 2;
            }
            else if (rarity == "Rare")
            {
                this.BonusDamage = 3;
            }
            else if (rarity == "Epic")
            {
                this.BonusDamage = 5;
            }
            else if (rarity == "Common")
            {
                this.BonusDamage = 1;
            }

            this.Name = name;
            this.Rarity = rarity;
        }

        //public string SumGems(Gem[] sockets)
        //{
        //    var sumStrength = 0;
        //    var sumAgility = 0;
        //    var sumVitality = 0;

        //    foreach (var gem in sockets)
        //    {
        //        if (gem != null)
        //        {
        //            sumStrength += gem.Strength;
        //            sumAgility += gem.Agility;
        //            sumVitality += gem.Vitality;
        //        }
        //    }
        //    return $"+{sumStrength} Strength, +{sumAgility} Agility, +{sumVitality} Vitality";
        //}

        public string Name { get; protected set; }

        public int Strength
        {
            get
            {
                var result = 0;
                foreach (var gem in Sockets)
                {
                    if (gem != null)
                    {
                        result += gem.Strength;
                    }
                }
                return result;
            }
            protected set => Strength = value;
        }

        public int Agility
        {
            get
            {
                var result = 0;
                foreach (var gem in Sockets)
                {
                    if (gem != null)
                    {
                        result += gem.Agility;
                    }
                }
                return result;
            }
            protected set => Agility = value;
        }

        public int Vitality
        {
            get
            {
                var result = 0;
                foreach (var gem in Sockets)
                {
                    if (gem != null)
                    {
                        result += gem.Vitality;
                    }
                }
                return result;
            }
            protected set => Vitality = value;
        }

        public int MinDamage
        {
            get => minDamage * BonusDamage + this.Strength * 2 + this.Agility;
            protected set => minDamage = value;
        }

        public int MaxDamage
        {
            get => maxDamage * BonusDamage + this.Strength * 3 + this.Agility * 4;
            protected set => maxDamage = value;
        }

        public string Rarity { get => rarity; protected set => rarity = value; }

        public Gem[] Sockets { get; protected set; }

        public int BonusDamage { get => bonusDamage; protected set => bonusDamage = value; }
    }
}