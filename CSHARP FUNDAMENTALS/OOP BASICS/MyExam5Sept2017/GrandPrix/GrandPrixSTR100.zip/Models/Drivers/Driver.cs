﻿public abstract class Driver
{
    private TyreFactory tyreFactory;

    protected Driver(string name, int hp, double fuelAmount, string tyreType, double tyreHardness, double grip)
    {
        Name = name;
        this.tyreFactory = new TyreFactory();
        this.Car = new Car(hp, fuelAmount, this.tyreFactory.CreateTyre(tyreType, tyreHardness, grip));
    }

    public string Name { get; }

    public double TotalTime { get; }

    public Car Car { get; }

    public abstract double FuelConsumptionPerKm { get; }

    public virtual double Speed => (this.Car.Hp + this.Car.Tyre.Degradation) / this.Car.FuelAmount;
}