﻿using System;
using System.Collections.Generic;

public class DraftManager
{
    private const string DefaultMode = "Full";
        
    private List<Harvester> harvesters;
    private List<Provider> providers;
    private string mode;
    private double totalMinedOre;
    private double totalStoredEnergy;

    public DraftManager()
    {
        this.harvesters = new List<Harvester>();
        this.providers = new List<Provider>();
        this.mode = DefaultMode;
    }

    public string RegisterHarvester(List<string> arguments)
    {
        var type = arguments[1];
        var id = arguments[2];

        try
        {
            if (arguments.Count == 5)
            {
                var harvester = new HammerHarvester(arguments[2], double.Parse(arguments[3]), double.Parse(arguments[4]));
                harvesters.Add(harvester);
            }
            else
            {
                var harvester = new SonicHarvester(arguments[2], double.Parse(arguments[3]), double.Parse(arguments[4]), int.Parse(arguments[5]));
                harvesters.Add(harvester);
            }
        }
        catch (Exception e)
        {
            return e.Message;
        }

        return $"Successfully registered {type} Harvester - {id}";
    }
    public string RegisterProvider(List<string> arguments)
    {
        var type = arguments[1];
        var id = arguments[2];

        try
        {
            if (arguments[1] == "Solar")
            {
                var provider = new SolarProvider(arguments[2], double.Parse(arguments[3]));
                providers.Add(provider);
            }
            else if (arguments[1] == "Pressure")
            {
                var provider = new PressureProvider(arguments[2], double.Parse(arguments[3]));
                providers.Add(provider);
            }
        }
        catch (Exception e)
        {
            return e.Message;
        }

        return $"Successfully registered {type} Provider - {id}";
    }
    public string Day()
    {
        return "A day has passed.";
    }
    public string Mode(List<string> arguments)
    {
        var mode = arguments[1];
        return $"Successfully changed working mode to {mode} Mode";
    }
    public string Check(List<string> arguments)
    {
        return "";
    }
    public string ShutDown()
    {
        return "";
    }

}