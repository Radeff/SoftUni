﻿using System.Collections.Generic;

public class DraftManager
{
    public string RegisterHarvester(List<string> arguments)
    {
        var type = arguments[1];
        var id = arguments[2];

        return $"Successfully registered {type} Harvester - {id}";
    }
    public string RegisterProvider(List<string> arguments)
    {
        var type = arguments[1];
        var id = arguments[2];

        return $"Successfully registered {type} Provider - {id}";
    }
    public string Day()
    {
        return "A day has passed.";
    }
    public string Mode(List<string> arguments)
    {
        var mode = arguments[1];
        return $"Successfully changed working mode to {mode} Mode";
    }
    public string Check(List<string> arguments)
    {
        return "";
    }
    public string ShutDown()
    {
        return "";
    }

}