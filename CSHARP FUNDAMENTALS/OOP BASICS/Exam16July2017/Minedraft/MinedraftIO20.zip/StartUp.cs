﻿using System;
using System.Linq;

public class StartUp
{
    public static void Main()
    {
        var input = Console.ReadLine()
            .Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
            .ToList();
        var dm = new DraftManager();
        var command = input[0];

        while (command != "Shutdown")
        {
            switch (command)
            {
                case "RegisterHarvester":
                    Console.WriteLine(dm.RegisterHarvester(input));
                    break;

                case "RegisterProvider":
                    Console.WriteLine(dm.RegisterProvider(input));
                    break;

                case "Day":
                    Console.WriteLine(dm.Day());
                    break;

                case "Check":
                    Console.WriteLine(dm.Check(input));
                    break;

                case "Mode":
                    Console.WriteLine(dm.Mode(input));
                    break;
            }

            input = Console.ReadLine()
                .Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
                .ToList();
            command = input[0];
        }

        Console.WriteLine(dm.ShutDown());
    }
}