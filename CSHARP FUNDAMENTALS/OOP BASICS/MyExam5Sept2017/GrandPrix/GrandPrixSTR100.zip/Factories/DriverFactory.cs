﻿public class DriverFactory
{
    public Driver CreateDriver(string type, string name, int hp, double fuelAmount, string tyreType, double tyreHardness, double grip)
    {
        if (type == "Aggressive")
        {
            return new AggressiveDriver(name,hp,fuelAmount,tyreType,tyreHardness,grip);
        }
        if (type == "Endurance")
        {
            return new EnduranceDriver(name, hp, fuelAmount, tyreType, tyreHardness, grip);
        }

        return null;
    }
}
