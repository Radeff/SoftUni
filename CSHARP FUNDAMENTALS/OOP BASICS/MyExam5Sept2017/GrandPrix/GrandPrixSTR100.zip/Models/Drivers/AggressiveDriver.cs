﻿public class AggressiveDriver : Driver
{
    private const double DefaultFuelConsumptionPerKm = 2.7;
    private const double SpeedMultiplier = 1.3;

    public AggressiveDriver(string name, int hp, double fuelAmount, string tyreType, double tyreHardness, double grip)
        : base(name, hp, fuelAmount, tyreType, tyreHardness, grip)
    {
    }

    public override double FuelConsumptionPerKm => DefaultFuelConsumptionPerKm;

    public override double Speed => base.Speed * SpeedMultiplier;
}