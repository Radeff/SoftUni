﻿using System;

public class UltrasoftTyre : Tyre
{
    public UltrasoftTyre(double hardness, double grip) : base(hardness)
    {
        this.Grip = grip;
    }

    public double Grip { get; }

    public override string Name => "Ultrasoft";

    public override double Degradation
    {
        get { return base.Degradation; }
        protected set
        {
            if (value < 30)
            {
                throw new Exception("Blown tyre");
            }

            this.Degradation = value;
        }
    }
}
