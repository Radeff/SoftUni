﻿using System;
using _11.InfernoInfinity.Gems;

namespace _11.InfernoInfinity
{
    public class StartUp
    {
        public static void Main()
        {
            var inputLine = Console.ReadLine();
            Weapon weapon = new Weapon();

            while (inputLine != "END")
            {
                var command = inputLine.Split(';');
                

                if (command[0] == "Create")
                {
                    var weaponData = command[1].Split();

                    if (weaponData[1] == "Axe")
                    {
                        weapon = new Axe(command[2], weaponData[0]);
                    }
                    else if (weaponData[1] == "Sword")
                    {
                        weapon = new Sword(command[2], weaponData[0]);
                    }
                    else if (weaponData[1] == "Knife")
                    {
                        weapon = new Knife(command[2], weaponData[0]);
                    }
                }

                else if (command[0] == "Add")
                {
                    Gem gem = new Gem();

                    if (weapon.Name == command[1])
                    {
                        var index = int.Parse(command[2]);
                        if (index >= 0 && index < weapon.Sockets.Length)
                        {
                            var gemData = command[3].Split();
                            switch (gemData[1])
                            {
                                case "Ruby":
                                    gem = new Ruby(gemData[0]);
                                        break;

                                case "Emerald":
                                    gem = new Emerald(gemData[0]);
                                    break;

                                case "Amethyst":
                                    gem = new Amethyst(gemData[0]);
                                    break;
                            }

                            weapon.Sockets[index] = gem;
                        }
                    }
                }
                else if (command[0] == "Remove")
                {
                    var index = int.Parse(command[2]);
                    if (index >= 0 && index < weapon.Sockets.Length)
                    {
                        if (weapon.Sockets[index] != null)
                        {
                            weapon.Sockets[index] = null;
                        }
                    }
                }
                else if (command[0] == "Print")
                {
                    if (weapon.Name == command[1])
                    {
                        Console.WriteLine($"{weapon.Name}: {weapon.MinDamage}-{weapon.MaxDamage} Damage, {weapon.SumGems(weapon.Sockets)}");
                    }
                }

                inputLine = Console.ReadLine();
            }
        }
    }
}
