﻿using System.Collections.Generic;

public class DraftManager
{
    public string RegisterHarvester(List<string> arguments)
    {
        return "";
    }
    public string RegisterProvider(List<string> arguments)
    {
        return "";
    }
    public string Day()
    {
        return "";
    }
    public string Mode(List<string> arguments)
    {
        return "";
    }
    public string Check(List<string> arguments)
    {
        return "";
    }
    public string ShutDown()
    {
        return "";
    }

}