﻿using System;
using System.Collections.Generic;
using System.Text;

public class DraftManager
{
    private const string DefaultMode = "Full";
    private const double HalfModeEnergyModifier = 0.6;
    private const double HalfModeOreModifier = 0.5;

    private List<Harvester> harvesters;
    private List<Provider> providers;
    private string mode;
    private double totalMinedOre;
    private double totalEnergyStored;

    public DraftManager()
    {
        this.harvesters = new List<Harvester>();
        this.providers = new List<Provider>();
        this.mode = DefaultMode;
    }

    public string RegisterHarvester(List<string> arguments)
    {
        var type = arguments[1];
        var id = arguments[2];

        try
        {
            if (arguments.Count == 5)
            {
                var harvester = new HammerHarvester(arguments[2], double.Parse(arguments[3]), double.Parse(arguments[4]));
                harvesters.Add(harvester);
            }
            else
            {
                var harvester = new SonicHarvester(arguments[2], double.Parse(arguments[3]), double.Parse(arguments[4]), int.Parse(arguments[5]));
                harvesters.Add(harvester);
            }
        }
        catch (Exception e)
        {
            return e.Message;
        }

        return $"Successfully registered {type} Harvester - {id}";
    }
    public string RegisterProvider(List<string> arguments)
    {
        var type = arguments[1];
        var id = arguments[2];

        try
        {
            if (arguments[1] == "Solar")
            {
                var provider = new SolarProvider(arguments[2], double.Parse(arguments[3]));
                providers.Add(provider);
            }
            else if (arguments[1] == "Pressure")
            {
                var provider = new PressureProvider(arguments[2], double.Parse(arguments[3]));
                providers.Add(provider);
            }
        }
        catch (Exception e)
        {
            return e.Message;
        }

        return $"Successfully registered {type} Provider - {id}";
    }
    public string Day()
    {
        var summedEnergyOutput = 0d;
        var summedOreOutput = 0d;
        var summedEnergyRequired = 0d;


        foreach (var harvester in harvesters)
        {
            summedEnergyRequired += harvester.EnergyRequirement;
            summedOreOutput += harvester.OreOutput;
        }

        foreach (var provider in providers)
        {
            summedEnergyOutput += provider.EnergyOutput;
        }

        this.totalEnergyStored += summedEnergyOutput;

        if (this.mode == "Half")
        {
            summedOreOutput *= HalfModeOreModifier;
            summedEnergyRequired *= HalfModeEnergyModifier;
        }

        if (this.mode != "Energy")
        {
            if (this.totalEnergyStored < summedEnergyRequired)
            {
                summedOreOutput = 0d;
            }
            else
            {
                this.totalEnergyStored -= summedEnergyRequired;
                this.totalMinedOre += summedOreOutput;
            }
        }
        else
        {
            summedOreOutput = 0d;
        }

        var sb = new StringBuilder();
        sb.AppendLine("A day has passed.");
        sb.AppendLine($"Energy Provided: {summedEnergyOutput}");
        sb.AppendLine($"Plumbus Ore Mined: {summedOreOutput}");

        return sb.ToString().Trim();
    }
    public string Mode(List<string> arguments)
    {
        this.mode = arguments[1];
        return $"Successfully changed working mode to {mode} Mode";
    }
    public string Check(List<string> arguments)
    {
        var id = arguments[1];
        var type = string.Empty;
        var workerName = string.Empty;
        var name = string.Empty;
        var sb = new StringBuilder();

        Worker worker = harvesters.Find(h => h.Id == id);
        if (worker != null)
        {
            type = nameof(Harvester);
            workerName = worker.GetType().Name;
            name = workerName.Substring(0, workerName.Length - 9);

            sb.AppendLine($"{name} {type} - {worker.Id}");
            sb.AppendLine($"Ore Output: {worker.OreOutput}");
            sb.AppendLine($"Energy Requirement: {worker.EnergyRequirement}");
        }
        else
        {
            worker = providers.Find(p => p.Id == id);
            if (worker == null)
            {
                sb.AppendLine($"No element found with id - {id}");
                return sb.ToString().Trim();
            }

            type = nameof(Provider);
            workerName = worker.GetType().Name;
            name = workerName.Substring(0, workerName.Length - 8);

            sb.AppendLine($"{name} {type} - {worker.Id}");
            sb.AppendLine($"Energy Output: {worker.EnergyOutput}");
        }

        return sb.ToString().Trim();
    }
    public string ShutDown()
    {
        var sb = new StringBuilder();
        sb.AppendLine("System Shutdown");
        sb.AppendLine($"Total Energy Stored: {this.totalEnergyStored}");
        sb.AppendLine($"Total Mined Plumbus Ore: {this.totalMinedOre}");

        return sb.ToString().Trim();
    }

}