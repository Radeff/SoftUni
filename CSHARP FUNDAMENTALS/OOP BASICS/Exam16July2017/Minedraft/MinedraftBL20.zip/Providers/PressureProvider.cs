﻿public class PressureProvider : Provider
{
    private const double EnergyOutputMultiplier = 1.5;

    public PressureProvider(double energyOutput, string id) : base(id, energyOutput )
    {
        base.EnergyOutput *= EnergyOutputMultiplier;
    }
}
