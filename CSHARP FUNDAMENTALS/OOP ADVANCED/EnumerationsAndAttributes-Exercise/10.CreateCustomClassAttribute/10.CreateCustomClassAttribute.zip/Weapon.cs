﻿namespace _10.CreateCustomClassAttribute
{
    [Kur(
        "Pesho",
        3,
        "Used for C# OOP Advanced Course - Enumerations and Attributes.",
        new string[] {"Pesho", "Svetlio"}
        )]
    
    public class Weapon
    {
        
    }
}