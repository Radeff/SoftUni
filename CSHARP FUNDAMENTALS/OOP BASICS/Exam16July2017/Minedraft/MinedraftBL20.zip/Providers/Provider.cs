﻿using System;
public abstract class Provider
{
    private const double MaxEnergyOutput = 10000;
    private const double MinEnergyOutput = 0;

    protected Provider( string id, double energyOutput)
    {
        this.Id = id;
        this.EnergyOutput = energyOutput;
    }
    
    public string Id { get; }

    public double EnergyOutput
    {
        get { return this.EnergyOutput; }

        protected set
        {
            if (this.EnergyOutput >= MaxEnergyOutput || this.EnergyOutput <= MinEnergyOutput)
            {
                throw new ArgumentException($"{nameof(Provider)} is not registered, because of it's {nameof(this.EnergyOutput)}");
            }
            this.EnergyOutput = value;
        }
    }
}
