﻿using System.Linq;
using _11.InfernoInfinity.Gems;

namespace _11.InfernoInfinity
{
    public class Weapon
    {
        private int strength;
        private int agility;
        private int vitality;
        private int minDamage;
        private int maxDamage;
        private string name;
        private string rarity;
        private Gem[] sockets;
        private int bonusDamage;

        public Weapon()
        {
            
        }
        public Weapon(string name, string rarity)
        {
            if (rarity == "Uncommon")
            {
                this.BonusDamage = 2;
            }
            else if (rarity == "Rare")
            {
                this.BonusDamage = 3;
            }
            else if (rarity == "Epic")
            {
                this.BonusDamage = 5;
            }
            else if (rarity == "Common")
            {
                this.BonusDamage = 1;
            }

            this.Name = name;
            this.Rarity = rarity;
        }

        public string SumGems(Gem[] sockets)
        {
            var sumStrength = 0;
            var sumAgility = 0;
            var sumVitality = 0;

            foreach (var gem in sockets)
            {
                if (gem != null)
                {
                    sumStrength += gem.Strength;
                    sumAgility += gem.Agility;
                    sumVitality += gem.Vitality;
                }
            }
            return $"+{sumStrength} Strength, +{sumAgility} Agility, +{sumVitality} Vitality";
        }

        public string Name { get; protected set; }

        public int Strength { get => strength; protected set => strength = value; }

        public int Agility { get => agility; protected set => agility = value; }

        public int Vitality { get => vitality; protected set => vitality = value; }

        public int MinDamage
        {
            get => minDamage * BonusDamage + this.Strength * 2 + this.Agility;
            protected set => minDamage = value;
        }

        public int MaxDamage
        {
            get => maxDamage * BonusDamage + this.Strength * 3 + this.Agility * 4;
            protected set => maxDamage = value;
        }

        public string Rarity { get => rarity; protected set => rarity = value; }

        public Gem[] Sockets { get; protected set; }

        public int BonusDamage { get => bonusDamage; protected set => bonusDamage = value; }
    }
}