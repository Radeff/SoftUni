﻿using System;
public abstract class Provider
{
    private double energyOutput;
    private const double MaxEnergyOutput = 10000;
    private const double MinEnergyOutput = 0;

    protected Provider(string id, double energyOutput)
    {
        this.Id = id;
        this.EnergyOutput = energyOutput;
    }
    
    public string Id { get; }

    public double EnergyOutput
    {
        get { return this.energyOutput; }

        protected set
        {
            if (value >= MaxEnergyOutput || value <= MinEnergyOutput)
            {
                throw new ArgumentException($"{nameof(Provider)} is not registered, because of it's {nameof(this.EnergyOutput)}");
            }

            this.energyOutput = value;
        }
    }
}
