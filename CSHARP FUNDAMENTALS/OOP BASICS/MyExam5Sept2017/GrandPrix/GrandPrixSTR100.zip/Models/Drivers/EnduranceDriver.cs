﻿public class EnduranceDriver : Driver
{
    private const double DefaultFuelConsumptionPerKm = 1.5;

    public EnduranceDriver(string name, int hp, double fuelAmount, string tyreType, double tyreHardness, double grip) : base(name, hp, fuelAmount, tyreType, tyreHardness, grip)
    {
    }

    public override double FuelConsumptionPerKm => DefaultFuelConsumptionPerKm;
}