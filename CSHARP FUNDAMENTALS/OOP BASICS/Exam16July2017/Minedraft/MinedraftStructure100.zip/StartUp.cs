﻿using System;
using System.Collections.Generic;
using System.Linq;

public class StartUp
{
    public static void Main()
    {
        var input = Console.ReadLine()
            .Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
            .ToList();

        var harvesters = new List<Harvester>();
        var providers = new List<Provider>();

        var command = input[0];

        while (command != "Shutdown")
        {
            var dm = new DraftManager();
            switch (command)
            {
                case "RegisterHarvester":
                    try
                    {
                        if (input.Count == 5)
                        {
                            var harvester = new HammerHarvester(input[2], double.Parse(input[3]), double.Parse(input[4]));
                            harvesters.Add(harvester);
                        }
                        else
                        {
                            var harvester = new SonicHarvester(input[2], double.Parse(input[3]), double.Parse(input[4]), int.Parse(input[5]));
                            harvesters.Add(harvester);
                        }

                        Console.WriteLine(dm.RegisterHarvester(input));
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;

                case "RegisterProvider":
                    try
                    {
                        if (input[1] == "Solar")
                        {
                            var provider = new SolarProvider(input[2], double.Parse(input[3]));
                            providers.Add(provider);
                        }
                        else if (input[1] == "Pressure")
                        {
                            var provider = new PressureProvider(input[2], double.Parse(input[3]));
                            providers.Add(provider);
                        }

                        Console.WriteLine(dm.RegisterProvider(input));
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    
                    break;

                case "Day":
                    dm.Day();
                    break;
                case "Check":
                    dm.Check(input);
                    break;
                case "Mode":
                    dm.Mode(input);
                    break;
            }

            input = Console.ReadLine()
                .Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
                .ToList();
            command = input[0];
        }
    }
}