﻿using _11.InfernoInfinity.Gems;

namespace _11.InfernoInfinity
{
    public class Axe : Weapon
    {
        public Axe(string name, string rarity) : base(name, rarity)
        {
            this.Sockets = new Gem[4];
            this.MaxDamage = 10;
            this.MinDamage = 5;
        }
    }
}