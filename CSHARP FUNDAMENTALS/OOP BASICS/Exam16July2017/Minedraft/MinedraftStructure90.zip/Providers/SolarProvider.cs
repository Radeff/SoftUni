﻿public class SolarProvider : Provider
{
    
    public SolarProvider(double energyOutput, string id) : base(id, energyOutput)
    {
    }
}
