﻿using System;
using System.Linq;

public class StartUp
{
    public static void Main()
    {
        var input = Console.ReadLine()
            .Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
            .ToList();

        var command = input[0];

        while (command != "Shutdown")
        {
            var dm = new DraftManager();
            switch (command)
            {
                case "RegisterHarvester":
                    dm.RegisterHarvester(input);
                    break;
                case "RegisterProvider":
                    dm.RegisterProvider(input);
                    break;
                case "Day":
                    dm.Day();
                    break;
                case "Check":
                    dm.Check(input);
                    break;
                case "Mode":
                    dm.Mode(input);
                    break;
            }

            input = Console.ReadLine()
                .Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries)
                .ToList();
            command = input[0];
        }
    }
}