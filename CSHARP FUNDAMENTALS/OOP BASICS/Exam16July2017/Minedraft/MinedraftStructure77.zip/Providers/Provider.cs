﻿using System;
using System.Threading;

public abstract class Provider
{
    protected Provider( string id, double energyOutput)
    {
        ID = id;
        EnergyOutput = energyOutput;
    }
    
    public string ID { get; }

    public double EnergyOutput
    {
        get { return this.EnergyOutput; }

        protected set
        {
            if (this.EnergyOutput >= 10000 || this.EnergyOutput <= 0)
            {
                throw new Exception($"{nameof(Provider)} is not registered, because of it's {nameof(this.EnergyOutput)}");
            }
            this.EnergyOutput = value;
        }
    }
}
