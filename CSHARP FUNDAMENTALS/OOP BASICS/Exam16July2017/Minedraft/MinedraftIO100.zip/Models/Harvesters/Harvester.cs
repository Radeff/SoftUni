﻿using System;

public abstract class Harvester : Worker
{
    private double oreOutput;
    private double energyRequirement;

    private const double MaxEnergyRequirement = 20000;
    private const double MinEnergyRequirement = 0;

    protected Harvester(string id, double oreOutput, double energyRequirement)
    {
        Id = id;
        OreOutput = oreOutput;
        EnergyRequirement = energyRequirement;
    }

    public override double OreOutput
    {
        get => this.oreOutput;

        protected set
        {
            if (value < MinEnergyRequirement)
            {
                throw new ArgumentException($"{nameof(Harvester)} is not registered, because of it's {nameof(this.OreOutput)}");
            }

            this.oreOutput = value;
        }
    }

    public override double EnergyRequirement
    {
        get => this.energyRequirement;

        protected set
        {
            if (value > MaxEnergyRequirement || value < MinEnergyRequirement)
            {
                throw new ArgumentException($"{nameof(Harvester)} is not registered, because of it's {nameof(this.EnergyRequirement)}");
            }

            this.energyRequirement = value;
        }
    }
}