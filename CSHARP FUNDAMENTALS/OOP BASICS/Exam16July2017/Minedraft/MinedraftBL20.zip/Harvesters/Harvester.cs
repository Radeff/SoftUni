﻿using System;

public abstract class Harvester
{
    private const double MaxEnergyRequirement = 20000;
    private const double MinEnergyRequirement = 0;

    protected Harvester(string id, double oreOutput, double energyRequirement)
    {
        Id = id;
        OreOutput = oreOutput;
        EnergyRequirement = energyRequirement;
    }

    public string Id { get; }

    public double OreOutput
    {
        get { return this.OreOutput; }

        protected set
        {
            if (this.OreOutput < MinEnergyRequirement)
            {
                throw new ArgumentException($"{nameof(Harvester)} is not registered, because of it's {nameof(this.OreOutput)}");
            }

            this.OreOutput = value;
        }
    }

    public double EnergyRequirement
    {
        get { return this.EnergyRequirement; }

        protected set
        {
            if (this.EnergyRequirement > MaxEnergyRequirement || this.EnergyRequirement < MinEnergyRequirement)
            {
                throw new ArgumentException($"{nameof(Harvester)} is not registered, because of it's {nameof(this.EnergyRequirement)}");
            }

            this.EnergyRequirement = value;
        }
    }
}